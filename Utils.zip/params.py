import re

USD = ('https://www.banki.ru/products/currency/cb/', '/html/body/div[1]/div[1]/main/div[2]/table/tbody/tr[1]/td[4]')
FEE = 3