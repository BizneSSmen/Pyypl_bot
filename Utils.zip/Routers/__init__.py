from .User_routers import userRouters

routers = [*userRouters]
