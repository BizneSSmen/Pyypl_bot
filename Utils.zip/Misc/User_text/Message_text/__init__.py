from ..Message_text import (
    answer_text,
    deposit,
    service_text,
    course,
    sbp,
    derive,
    cash_exchange
)
