from ..Buttons_text import (
    deposit,
    main_menu,
    service,
    derive,
    cash_exchange
)
