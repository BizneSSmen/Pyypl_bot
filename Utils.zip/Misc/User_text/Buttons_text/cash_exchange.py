from enum import Enum


class CashExchange(Enum):
    wallet1: str = "Рубли"
    wallet2: str = "Доллары"
    wallet3: str = "Дирхамы"
