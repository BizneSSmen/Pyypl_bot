from ..User_text import (
    Buttons_text,
    Message_text,
)